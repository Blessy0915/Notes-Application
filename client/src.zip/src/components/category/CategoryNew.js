import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
import CategoryForm from './CategoryForm'

export default class CategoryNew extends React.Component
{
    handleSubmit = (formData) =>
    {
        axios.post('http://localhost:3025/categories', formData,{
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            if(response.data.hasOwnProperty('errors'))
            {
                alert(response.data.message)
            }
            else
            {
                const data = response.data
                this.props.history.push(`/categories/${data._id}`)
            }
            console.log(response.data)
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    render()
    {
        return (
            <div align = "center"> 
                <h2><u>Add Category</u></h2> 
                < CategoryForm handleSubmit = {this.handleSubmit}/>
            </div>
        )
    }
}