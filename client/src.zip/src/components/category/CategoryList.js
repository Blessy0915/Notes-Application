import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom' 

export default class CategoryList extends React.Component
{
    constructor()
    {
        super()
        this.state = {
            categories : []
        }
    }
    componentDidMount()
    {
        axios.get('http://localhost:3025/categories', {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            const categories = response.data
            this.setState({categories})
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    handleRemove = (id) =>
    {
        axios.delete(`http://localhost:3025/categories/${id}`, {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            const data = response.data
            this.setState((prevState)=>
            {
                const categories = prevState.categories.filter((category)=>
                {
                    return category._id !== data._id
                })
                return ({categories})
            })
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    render()
    {
        return(
            <div align = "center">
                <h2>Categories : {this.state.categories.length}</h2>
                <table border = "1">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Action</th>
                            <th>Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.categories.map((category)=>
                            {
                                return(
                                    <tr key = {category._id}>
                                        <td>{category.name}</td>
                                        <td><Link to = {`/categories/${category._id}`}>Show</Link></td>
                                        <td><button onClick = {()=>
                                        {
                                            this.handleRemove(category._id)
                                        }}>Remove</button></td>
                                    </tr>

                                )
                            })
                        }
                    </tbody>
                </table>
                <Link to = "/categories/new">Add a category</Link>
            </div>

        )
    }
}
