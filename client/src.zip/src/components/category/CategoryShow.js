import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'


export default class CategoryShow extends React.Component
{
    constructor()
    {
        super()
        this.state = {
            category : {},
            notes : []
        }
    }
    componentDidMount()
    {
        const id = this.props.match.params.id
        console.log(id)
        axios.get(`http://localhost:3025/categories/${id}`,
        {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            
            const category = response.data
            const notes = category.notes
            this.setState({category, notes})
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    render()
    {
        const {_id, name} = this.state.category
        
        return(
            <div align = "left">
                <h2>{name}</h2>
                <ul>
                {
                    this.state.notes.map((note)=>
                    {
                        return(
                            <li key = {note._id}><Link to = {`/notes/${note._id}`}>{note.title}</Link></li>
                        )
                    })
                }
                </ul><br/>
                <Link to = {`/categories/edit/${_id}`}>Edit |</Link>
                <Link to = "/categories">Back</Link>
            </div>
        )
    }
}