import React from 'react'

export default function Home()
{
    return(
        <div align = "center">
            <h1><u>Notes App</u></h1>
            <h2>Welcome to the Notes App!!</h2>
        </div>
    )
}