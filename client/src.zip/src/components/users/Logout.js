import React from 'react'
import Axios from 'axios'

export default class Logout extends React.Component
{
    componentDidMount()
    {
        Axios.delete('http://localhost:3025/users/logout', {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            localStorage.clear()
            alert(response.data)
            this.props.history.push('/')
        })
        .catch((err)=>
        {
            alert(err)
        })
    }
    render()
    {
        return(
            <div>
                
            </div>
        )
    }
}