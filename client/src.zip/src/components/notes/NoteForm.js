import React from 'react'
import axios from 'axios'
export default class NoteForm extends React.Component
{
    constructor(props)
    {
        super()
        this.state = {
            title : props.title? props.title : '',
            body : props.body ? props.body : '',
            category : props.category ? props.category : '',
            categories : []
        }
    }
    componentDidMount()
    {
        axios.get('http://localhost:3025/categories', {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            const categories = response.data
            this.setState({categories})
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    handleChange = (e) =>
    {
        this.setState({
            [e.target.name] : e.target.value
        })
    }
    handleSubmit = (e) =>
    {
        e.preventDefault()
        const formData = {
            title : this.state.title,
            body : this.state.body,
            category : this.state.category

        }
        this.props.handleSubmit(formData)
    }
    render()
    {
        return(
            <div align = "center">
                <form onSubmit = {this.handleSubmit}>
                    <label>Title<br/>
                        <input type = "text"
                               value = {this.state.title}
                               name = "title"
                               onChange = {this.handleChange}/>
                    </label><br/>
                    <label>Body<br/>
                        <textarea value = {this.state.body}
                                  name = "body"
                                  onChange = {this.handleChange}>
                        </textarea>
                    </label><br/>
                    <label>category<br/>
                        <select onChange = {this.handleChange} name = "category">
                            <option>select</option>
                            {
                                this.state.categories.map((category)=>
                                {
                                    return (
                                        <option key = {category._id} value = {category._id}>{category.name}</option>
                                    )
                                })
                            }
                        </select>
                    </label><br/><br/>
                    <input type = "submit"/>
                </form>
            </div>
        )
    }
}