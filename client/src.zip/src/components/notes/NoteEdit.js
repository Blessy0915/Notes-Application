import React from 'react'
import axios from 'axios'
import NoteForm from './NoteForm'

export default class NoteEdit extends React.Component
{
    constructor()
    {
        super()
        this.state = {
            note : {}
        }
    }
    componentDidMount()
    {
        const id = this.props.match.params.id
        console.log(id,12)
        axios.get(`http://localhost:3025/notes/${id}`, {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            const note = response.data
            this.setState({note})
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    handleSubmit = (formData) =>
    {
        const id = this.props.match.params.id
        axios.put(`http://localhost:3025/notes/${id}`, formData, {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            if(response.data.hasOwnProperty('errors'))
            {
                alert(response.data.message)
            }
            else
            {
                this.props.history.push(`/notes/${id}`)
            }
        })
    }
    render()
    {
        return(
            <div>
                {
                    Object.keys(this.state.note).length !=0 &&  <NoteForm {...this.state.note} handleSubmit = {this.handleSubmit}/>
                }
               
            </div>
        )
    }
}