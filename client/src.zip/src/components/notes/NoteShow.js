import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'

export default class NoteShow extends React.Component
{
    constructor()
    {
        super()
        this.state = {
            note : {},
            category : {}
        }
    }
    componentDidMount()
    {
        const id = this.props.match.params.id
        axios.get(`http://localhost:3025/notes/${id}`, {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            const note = response.data
            const category = note.category
            this.setState({note, category})
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    render()
    {
        const {_id,title, body} = this.state.note
        const { name } = this.state.category
        return(
            <div align = "center">
                <h2>{title}</h2>
                
                <p>category : {name}<br/>{body}</p>
                <Link to = {`/notes/edit/${_id}`}>Edit | </Link>
                <Link to = "/notes">back</Link>
            </div>
        )
    }
}
