import React from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'
export default class NoteList extends React.Component
{
    constructor()
    {
        super()
        this.state = {
            notes : []
        }
    }
    handleRemove = (id) =>
    {
        axios.delete(`http://localhost:3025/notes/${id}`, {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            console.log(response.data)
            const data = response.data
            this.setState((prevState)=>
            {
                const notes = prevState.notes.filter((note)=>
                {
                    return note._id != data._id
                })
                return ({notes})
            })
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    componentDidMount()
    {
        axios.get('http://localhost:3025/notes', {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            const notes = response.data
            this.setState({notes})
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    render()
    {
        return (
            <div align = "center">
              <h2>Listing Notes- {this.state.notes.length} </h2>  
              { 
                  this.state.notes.map((note)=>
                  {
                      return(
                          <div key = {note._id}>
                              <b>{note.title}-<small>{note.category.name}</small></b>
                              <p>{note.body}</p>

                              <Link to = {`/notes/${note._id}`}>show |</Link>
                              <button onClick = {()=>
                            {
                                this.handleRemove(note._id)
                            }}>Remove</button>
                              <hr/>
                          </div>
                      )
                  })
              }
              <Link to = "/notes/new">Add a note</Link>
            </div>
        )
    }
}