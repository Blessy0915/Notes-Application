import React from 'react'
import NoteForm from './NoteForm'
import Axios from 'axios'
export default class NoteNew extends React.Component
{
    handleSubmit = (formData) =>
    {
        Axios.post('http://localhost:3025/notes', formData, {
            headers : {
                'x-auth' : localStorage.getItem('authToken')
            }
        })
        .then((response)=>
        {
            if(response.data.hasOwnProperty('errors'))
            {
                alert(response.data.message)
            }
            else
            {
                const id = response.data._id
                this.props.history.push(`/notes/${id}`)
            }
        })
        .catch((err)=>
        {
            console.log(err)
        })
    }
    render()
    {
        return(
            <div align = "center">
                <h2><u>Add a Note</u></h2>
                <NoteForm handleSubmit = {this.handleSubmit}/>
            </div>
        )
    }
}