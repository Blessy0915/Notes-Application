import React from 'react';
import './App.css';
import {BrowserRouter, Link, Route, Switch} from 'react-router-dom'

import Home from './components/common/Home'
import RegisterForm from './components/users/Register'
import LoginForm from './components/users/Login'
import Logout from './components/users/Logout'

import NoteList from './components/notes/NoteList'
import NoteShow from './components/notes/NoteShow'
import NoteNew from './components/notes/NoteNew'
import NoteEdit from './components/notes/NoteEdit'

import CategoryList from './components/category/CategoryList'
import CategoryShow from './components/category/CategoryShow'
import CategoryNew from './components/category/CategoryNew'
import CategoryEdit from './components/category/CategoryEdit'

function App() {
  return (
    <BrowserRouter>
    
      
      <div align = "right">
        
          <Link to = "/" >Home</Link>
          {
            localStorage.getItem('authToken') ? 
            <div>
              <Link to = "/notes"> | Notes</Link>
              <Link to = "/categories"> | Categories </Link>
              <Link to = "/users/logout">Logout</Link>
            </div>
            :
            <div>
              <Link to = "/users/register"> | Register</Link>
              <Link to = "/users/login"> | Login</Link>
            </div>
          } 

         
    
        <Switch>
          <Route path = "/" component = {Home} exact = {true}/>
          <Route path = "/users/register" component = {RegisterForm}/>
          <Route path = "/users/login" component = {LoginForm}/>
          <Route path = "/users/logout" component = {Logout}/>

          <Route path = "/notes" component = {NoteList} exact = {true}/>
          <Route path = "/notes/new" component = {NoteNew}/>
          <Route path = "/notes/edit/:id" component = {NoteEdit}/>
          <Route path = "/notes/:id" component = {NoteShow}/>

          <Route path = "/categories" component = {CategoryList} exact = {true}/>
          <Route path = "/categories/new" component = {CategoryNew}/>
          <Route path = "/categories/edit/:id" component = {CategoryEdit}/>

          <Route path = "/categories/:id" component = {CategoryShow}/>
        </Switch>
      </div>
    
    </BrowserRouter>
  );
}

export default App;
